/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package isptec.pii.pp2;

import java.util.*;

/**
 *
 * @author ligor
 */
public class Administrador {
    ArrayList <String> nivel;
    
    
    static void PreencherNivel (int niveis, String difnivel){
        ArrayList <String> nivel = new ArrayList <String>();
        if (niveis == 4) {
            for (int i = 1; i <= niveis; i++) {
                System.out.print("Nivel [" + i + "]: ");
                String aux = difnivel;
                nivel.add(aux);
            }
        }
    }
    
    static void ImprimirNivel (){
        ArrayList <String> nivel = new ArrayList <String>();
        int cont = 0;
        for (String dificuldade : nivel) {
            cont++;
            System.out.println("["+cont+"]:" + dificuldade);
        }
    }
    
    static void PreencherTema (int nTemas, String tema){
        ArrayList <String> temas = new ArrayList <String>();
        if ((nTemas == 4)){
            for (int i = 1; i <= 4; i++) {
                System.out.print("Tema [" + i + "]: ");
                temas.add(tema);
            }
        }
    }
    
    static void ImprimirTema (){
        ArrayList <String> temas = new ArrayList <String>();
        int cont = 0;
        System.out.println("-----TEMAS-----");
        for (String themes : temas) {
            cont++;
            System.out.println("["+cont+"]: "  + themes);
        }
    }
    
    static void PreencherPergunta (int nPerguntas, String pergunta, String resposta){
        ArrayList <String> perguntas = new ArrayList <String>();
        if (nPerguntas == 3 || nPerguntas == 4) { 
            
            int cont = 0;
            for (int i = 1; i <= nPerguntas; i++) {
                cont++;
                System.out.print("Pergunta [" +cont+ "]: ");
                perguntas.add(pergunta);
            }
        }
    }
    
    static void ImprimirPergunta (){
        ArrayList <String> perguntas = new ArrayList <String>();
        int cont = 0;
        for (String question : perguntas) {
            cont++;
            System.out.println("["+ cont+"]: " + question);
        }
    }
    
    static void PreencherResposta (int nResposta, String resposta){
        ArrayList <String> respostas = new ArrayList <String>();
        switch (nResposta){
            case 1:
                respostas.add(resposta);
                break;
            case 2:
                respostas.add(resposta);
                break;
            case 3:
                respostas.add(resposta);
                break;
            case 4:
                respostas.add(resposta);
                break;
        }
    }
    
    static void PreencherOpcoesDasRespotas (int nPerguntas, String opResposta){
        ArrayList <String> opcoes = new ArrayList <String>();
        int cont = 0;
        for (int i = 1; i <= nPerguntas; i++) {
            cont++;
            System.out.print("Opcao [" +cont+ "]: ");
            opcoes.add(opResposta);
        }
    }
    
    static void ImprimirOpcoes (){
        ArrayList <String> opcoes = new ArrayList <String>();
        int cont = 0;
        for (String options : opcoes) {
            cont++;
            System.out.println("["+ cont+"]: " + options);
        }
    }
    
    static void OpcaoCerta (){
        ArrayList <String> respostas = new ArrayList <String>();
        ArrayList <String> opcoes = new ArrayList <String>();
        for (String opciones : opcoes){                                                                
            if (respostas.contains(opciones)) {
                System.out.println("Opcao correta, parabens!");
            }
            else{
                System.out.println("Opcao incorreta, infelizmente.");
            }
        }
    }
}
