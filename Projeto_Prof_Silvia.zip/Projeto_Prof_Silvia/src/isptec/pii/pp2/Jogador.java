/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package isptec.pii.pp2;

import java.util.*;

/**
 *
 * @author ligor
 */
public class Jogador {
    ArrayList <String> nome;
    ArrayList <Integer> dia;
    ArrayList <Integer> mes;
    ArrayList <Integer> ano;
    String nomes;
    int day;
    int month;
    int year;
    
    
    
    static void PreencherNome (String nomes){
        ArrayList <String> nome = new ArrayList <String>();
        nome.add(nomes);
    }
    static void ImprimirNome (){
        ArrayList <String> nome = new ArrayList <String>();
        for (String names: nome) {
            System.out.println("Nome: " + names);
        }
    }
    static void PreencherDia (int day, int num){
        ArrayList <Integer> dia = new ArrayList <Integer>();
        for (int i = 1; i <= num; i++) {
            
            if (day > 0 && day <= 31) {
                dia.add(day);
            }
        }
    }
    static void ImprimirDia (){
        ArrayList <Integer> dia = new ArrayList <Integer>();
        for (int dias: dia) {
            System.out.print("Data de Nascimento: " + dias + "/");
        }
    }
    
    static void PreencherMes (int month, int num){
        ArrayList <Integer> mes = new ArrayList <Integer>();
        for (int i = 1; i <= num; i++) {
            
            if (month > 0 && month <= 12) {
                mes.add(month);
            }
        }   
    }
    
    static void ImprimirMes (){
        ArrayList <Integer> mes = new ArrayList <Integer>();
        for (int meses: mes) {
            System.out.print(meses + "/");
        }
    }
    
    static void PreencherAno (int year, int num){
        ArrayList <Integer> ano = new ArrayList <Integer>();
        for (int i = 1; i <= num; i++) {
            
            if (year > 0) {
                ano.add(year);
            }
        }
    }
    
    static void ImprimirAno (){
        ArrayList <Integer> ano = new ArrayList <Integer>();
        for (int anos: ano) {
            System.out.println(anos);
        }
    }
}
