/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package isptec.pii.pp2;

import java.util.*;

/**
 *
 * @author ligor
 */
public class Eat_Code {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner ler = new Scanner (System.in);
        
        int opcao, cont = 0;
        
            //char letra = (char) opcao;
            //opcao = letra;
            
        do{
            System.out.println("--------MENU--------");
            System.out.println("[1] - JOGADOR: ");
            System.out.println("[2] - ADMINISTRADOR: ");
            System.out.println("[3] - INICIAR JOGO:");

            System.out.println(" ");

            System.out.println("Digite a opcao desejada: ");
            opcao = ler.nextInt();
            
            
            int tentativas = 1;
            
            ler.nextLine();

            while (!(opcao > 0 && opcao < 4)){
                System.out.println("Opcao inexistente! ");
                System.out.println("----------");
                System.out.println("Digite novamente!");
                //String letra = ler.next();
                //opcao = Integer.valueOf(letra);
                opcao = ler.nextInt();
                tentativas++;
                if (tentativas == 5) {
                    System.out.println("");
                    System.out.println("Infelizmente tivemos que encerrar o programa, reinicei por favor. Excedeu no numero de tentativas!");
                    ler.close();
                    break;
                }
            }
            
            
                /*System.out.println("--------MENU--------");
                System.out.println("[1] - JOGADOR: ");
                System.out.println("[2] - ADMINISTRADOR: ");
                System.out.println("[3] - INICIAR JOGO:");

                System.out.println(" ");

                System.out.println("Digite a opcao desejada: ");
                opcao = ler.nextInt();*/

                //while(opcao > 0 && opcao < 4){
                if (opcao > 0 && opcao < 4){
                    switch (opcao) {
                        case 1: 
                            //nome.add(name);
                                //name = ler.nextLine();
                            /*System.out.println("Digite o nome do Jogador: ");
                            String nomes = ler.nextLine();
                            nome.add(nomes);
                            nomes = ler.nextLine();*/


                            /*String nomes = ler.nextLine();
                                nome.add(nomes);
                                nomes = ler.nextLine();
                                nome.add(nomes);
                                nomes = ler.nextLine();*/

                            System.out.println("");
                            System.out.println("Quantos jogadores deseja inserir: ");
                            int num = ler.nextInt();

                            System.out.println("");
                            System.out.println("-----PREENCHA OS DADOS DO JOGADOR----- ");

                            ler.nextLine();

                            for (int i = 1; i <= num; i++) {
                                System.out.println("Digite o nome do Jogador: ");
                                String nomes = ler.nextLine();
                                
                                //Funcao que permite o preenchimento do nome
                                Jogador.PreencherNome(nomes);
                            }

                            //ler.nextLine();

                            int day, month, year;

                            System.out.println("");
                            
                            System.out.println("Digite o dia do jogador:");
                            day = ler.nextInt();
                            while (!(day > 0 && day <= 31)) {
                                System.out.println("Dia do jogador e inexistente");
                                System.out.println("Digite novamente o dia: ");
                                day = ler.nextInt();
                            } 
                            
                            //Funcao que permite o preenchimento do dia
                            Jogador.PreencherDia(day, num);
                            
                            System.out.println("");
                            System.out.println("Digite o mes do jogador: ");
                            month = ler.nextInt();
                            while (!(month > 0 && month <= 12)) {
                                System.out.println("Mes do jogador e inexistente");
                                System.out.println("Digite novamente o mes: ");
                                month = ler.nextInt();
                            }
                                
                            //Funcao que permite o preenchimento do mes
                            Jogador.PreencherMes(month, num);

                            System.out.println("");
                            System.out.println("Digite o ano do jogador: ");
                            year = ler.nextInt();
                                while (!(year > 0)) {
                                    System.out.println("Ano do jogador e inexistente");
                                    System.out.println("Digite novamente o ano: ");
                                    year = ler.nextInt();
                                }
                                
                                //Funcao que permite o preenchimento do ano
                                Jogador.PreencherAno(year, num);

                            ler.nextLine();

                            System.out.println("");
                            System.out.println("---- APRESENTACAO DOS DADOS----");
                            //Funcao que permite a impressao do nome
                            Jogador.ImprimirNome();
                            
                            //Funcao que permite a impressao do dia
                            Jogador.ImprimirDia();
                            
                            //Funcao que permite a impressao do mes
                            Jogador.ImprimirMes();
                            
                            //Funcao que permite a impressao do ano
                            Jogador.ImprimirAno();
                            
                            System.out.println("Preenchimento dos dados feito com sucesso! ");
                            break;


                        case 2:
                            int niveis, nTemas, nPerguntas, temaP;
                            ArrayList <String> temas = new ArrayList <String>();
                            ArrayList <String> nivel = new ArrayList <String>();
                            ArrayList <String> perguntas = new ArrayList <String>();
                            ArrayList <String> opcoes = new ArrayList <String>();
                            ArrayList <String> respostas = new ArrayList <String>();
                            
                            
                            
                            System.out.println("Quantos niveis o jogo deve possuir? ");
                            niveis = ler.nextInt();

                            while (!(niveis == 4)){
                                System.out.println("O jogo so pode possuir 4 niveis! ");
                                System.out.println("Digite novamente o nivel:");
                                niveis = ler.nextInt();
                            }
                            
                            ler.nextLine();
                            
                                System.out.println("");
                                System.out.println("----PREENCHIMENTO DOS NIVEIS DE DIFICULDADE----");
                                String difnivel = ler.nextLine();
                                Administrador.PreencherNivel(niveis, difnivel);
                                
                                System.out.println("");
                                
                                System.out.println("-----NIVEIS-----");
                                Administrador.ImprimirNivel();
                                
                                ler.nextLine();
                                
                                System.out.println("");
                                System.out.println("Deseja jogar em qual nivel de dificuldade? ");
                                int dif = ler.nextInt();
                                
                                /*while (dif < 1 || dif > nivel.size() ) {                                    
                                    System.out.println("Nivel inexistente!");
                                    System.out.println("Digite novamente o nivel de dificuldade:");
                                    dif = ler.nextInt();
                                }*/
                                
                                //if(dif > 0 && dif <= nivel.size()){
                                    switch (dif){
                                        case 1:
                                            System.out.println("Quantos temas deseja inserir? ");
                                            nTemas = ler.nextInt();

                                            ler.nextLine();

                                            while (!(nTemas == 4)) {                                        
                                                System.out.println("Deve ter 4 temas!");
                                                System.out.println("Digite novamente! ");
                                                nTemas = ler.nextInt();
                                                break;
                                            }

                                            ler.nextLine();

                                            System.out.println("-----PREENCHIMENTO DOS TEMAS PARA ESTE NIVEL-----");
                                            if ((nTemas == 4)){
                                                for (int i = 1; i <= 4; i++) {
                                                    System.out.print("Tema [" + i + "]: ");
                                                    String tema = ler.nextLine();
                                                    temas.add(tema);
                                                }
                                            }

                                            ler.nextLine();

                                            cont = 0;
                                            System.out.println("-----TEMAS-----");
                                            for (String themes : temas) {
                                                cont++;
                                                System.out.println("["+cont+"]: "  + themes);
                                            }

                                            System.out.println("");
                                            System.out.println("Digite o numero de perguntas que deseja inserir:");
                                            nPerguntas = ler.nextInt();

                                            while (!(nPerguntas == 3 || nPerguntas == 4) ) {                                            
                                                System.out.println("O jogo deve possuir no minimo 3 perguntas!");
                                                System.out.println("Digite novamente o numero de perguntas que deseja inserir: ");
                                                nPerguntas = ler.nextInt();
                                            }

                                            ler.nextLine();

                                            System.out.println("Digite qual o tema que deseja que a pergunta seja inserida:");
                                            temaP = ler.nextInt();

                                           // System.out.println("");
                                            /*while ((temaP < 1 || temaP > temas.size())) {
                                                System.out.println("Deve selecionar as opcoes disponiveis!");
                                                System.out.println("Digite navamente o tema que deseja que a pergunta seja inserida!");
                                                temaP = ler.nextInt();
                                            }*/
                                           //if (temaP > 0 && temaP <= temas.size()) {
                                            ler.nextLine();
                                            if (nPerguntas == 3 || nPerguntas == 4) {
                                                switch (temaP ){ //temas.size()
                                                    case 1:
                                                            System.out.println("-----PREENCHIMENTO DAS PERGUNTAS PARA ESTE NIVEL-----");
                                                            cont = 0;
                                                            for (int i = 1; i <= nPerguntas; i++) {
                                                                cont++;
                                                                System.out.print("Pergunta [" +cont+ "]: ");
                                                                String  pergunta = ler.nextLine();
                                                                perguntas.add(pergunta);
                                                            }

                                                            ler.nextLine();

                                                            System.out.println("-----PERGUNTAS-----");
                                                            cont = 0;
                                                            for (String question : perguntas) {
                                                                cont++;
                                                                System.out.println("["+ cont+"]: " + question);
                                                            }
                                                            
                                                            ler.nextLine();
                                                            
                                                            String resposta;
                                                            int option = 0;
                                                            System.out.println("-----PREENCHIMENTO DA RESPOSTA-----");
                                                            System.out.println("Digite o numero da pergunta que deseja adicionar a resposta:");
                                                            int nResposta = ler.nextInt();
                                                            
                                                            ler.nextLine();
                                                            
                                                            switch (nResposta){
                                                                case 1:
                                                                    System.out.println("Digite a resposta:");
                                                                    resposta = ler.nextLine();
                                                                    respostas.add(resposta);
                                                                    break;
                                                                case 2:
                                                                    System.out.println("Digite a resposta:");
                                                                    resposta = ler.nextLine();
                                                                    respostas.add(resposta);
                                                                    break;
                                                                case 3:
                                                                    System.out.println("Digite a resposta:");
                                                                    resposta = ler.nextLine();
                                                                    respostas.add(resposta);
                                                                    break;
                                                                case 4:
                                                                    System.out.println("Digite a resposta:");
                                                                    resposta = ler.nextLine();
                                                                    respostas.add(resposta);
                                                                    break;
                                                            }
                                                            
                                                           //System.out.println(respostas);
                                                            
                                                            System.out.println("");
                                                            System.out.println("-----OPCOES DAS RESPOSTAS-----");
                                                            cont = 0;
                                                            for (int i = 1; i <= nPerguntas; i++) {
                                                                cont++;
                                                                System.out.print("Opcao [" +cont+ "]: ");
                                                                String  opResposta = ler.nextLine();
                                                                opcoes.add(opResposta);
                                                            }
                                                            
                                                            System.out.println("");
                                                            System.out.println("-----OPCOES-----");
                                                            cont = 0;
                                                            for (String options : opcoes) {
                                                                cont++;
                                                                System.out.println("["+ cont+"]: " + options);
                                                            }
                                                            
                                                            ler.nextLine();
                                                            
                                                            System.out.println("Selcione a opcao certa:");
                                                            int opCerta = ler.nextInt();
                                                            
                                                            for (String opciones : opcoes){                                                                
                                                                if (respostas.contains(opciones)) {
                                                                    System.out.println("Opcao correta, parabens!");
                                                                }
                                                                else{
                                                                    System.out.println("Opcao incorreta, infelizmente.");
                                                                }
                                                            }
                                                            System.out.println("");
                                                            
                                                            //System.out.println("resposta: " + respostas);
                                                            
                                                            //System.out.println("Selcione a opcao certa:");
                                                            //int opCerta = ler.nextInt();
                                                            
                                                            
                                                            /*switch (opCerta) {
                                                                case 1:
                                                                    if (opcoes.contains(respostas)) {
                                                                        System.out.println("Opcao correta, parabens!");
                                                                    }
                                                                    else{
                                                                        System.out.println("Opcao incorreta, infelizmente.");
                                                                    }
                                                                    break;
                                                                case 2:
                                                                    if (opcoes.contains(respostas)) {
                                                                        System.out.println("Opcao correta, parabens!");
                                                                    }
                                                                    else{
                                                                        System.out.println("Opcao incorreta, infelizmente.");
                                                                    }
                                                                    break;
                                                                case 3:
                                                                    if (opcoes.contains(respostas)) {
                                                                        System.out.println("Opcao correta, parabens!");
                                                                    }
                                                                    else{
                                                                        System.out.println("Opcao incorreta, infelizmente.");
                                                                    }
                                                                    break;
                                                                case 4:
                                                                    if (opcoes.contains(respostas)) {
                                                                        System.out.println("Opcao correta, parabens!");
                                                                    }
                                                                    else{
                                                                        System.out.println("Opcao incorreta, infelizmente.");
                                                                    }
                                                                    break;   
                                                            }*/
                                                        break;
                                                    case 2:
                                                        /*if (nPerguntas == 3 || nPerguntas == 4) {
                                                            System.out.println("-----PREENCHIMENTO DAS PERGUNTAS PARA ESTE NIVEL-----");
                                                            cont = 0;
                                                            for (int i = 1; i <= nPerguntas; i++) {
                                                                cont++;
                                                                System.out.print("Pergunta [" +cont+ "]: ");
                                                                String  pergunta = ler.nextLine();
                                                                perguntas.add(pergunta);
                                                            }

                                                            ler.nextLine();

                                                            System.out.println("-----APRESENTACAO DAS PERGUNTAS-----");
                                                            cont = 0;
                                                            for (String question : perguntas) {
                                                                cont++;
                                                                System.out.println("["+ cont+"]: " + question);
                                                            }
                                                        }*/
                                                        break;
                                                    case 3:
                                                        /*if (nPerguntas == 3 || nPerguntas == 4) {
                                                            System.out.println("-----PREENCHIMENTO DAS PERGUNTAS PARA ESTE NIVEL-----");
                                                            cont = 0;
                                                            for (int i = 1; i <= nPerguntas; i++) {
                                                                cont++;
                                                                System.out.print("Pergunta [" +cont+ "]: ");
                                                                String  pergunta = ler.nextLine();
                                                                perguntas.add(pergunta);
                                                            }

                                                            ler.nextLine();

                                                            System.out.println("-----APRESENTACAO DAS PERGUNTAS-----");
                                                            cont = 0;
                                                            for (String question : perguntas) {
                                                                cont++;
                                                                System.out.println("["+ cont+"]: " + question);
                                                            }
                                                        }*/
                                                        break;
                                                    case 4:
                                                        /*if (nPerguntas == 3 || nPerguntas == 4) {
                                                            System.out.println("-----PREENCHIMENTO DAS PERGUNTAS PARA ESTE NIVEL-----");
                                                            cont = 0;
                                                            for (int i = 1; i <= nPerguntas; i++) {
                                                                cont++;
                                                                System.out.print("Pergunta [" +cont+ "]: ");
                                                                String  pergunta = ler.nextLine();
                                                                perguntas.add(pergunta);
                                                            }

                                                            ler.nextLine();

                                                            System.out.println("-----APRESENTACAO DAS PERGUNTAS-----");
                                                            cont = 0;
                                                            for (String question : perguntas) {
                                                                cont++;
                                                                System.out.println("["+ cont+"]: " + question);
                                                            }
                                                        }*/
                                                        break;
                                                }
                                            }
                                            break;
                                        case 2:
                                            /*System.out.println("Quantos temas deseja inserir? ");
                                            nTemas = ler.nextInt();
                                            System.out.println("Quais os temas que deseja para este nivel? ");

                                            //ler.nextLine();

                                            while (!(nTemas == 4)) {                                        
                                                System.out.println("So pode ter ate 4 temas!");
                                                System.out.println("Digite novamente! ");
                                                nTemas = ler.nextInt();
                                                break;
                                            }

                                            ler.nextLine();

                                            if ((nTemas == 4)){
                                                for (int i = 1; i <= 4; i++) {
                                                    System.out.print("Tema [" + i + "]: ");
                                                    String tema = ler.nextLine();
                                                    temas.add(tema);
                                                }
                                            }

                                            ler.nextLine();

                                            cont = 0;
                                            System.out.println("-----TEMAS-----");
                                            for (String themes : temas) {
                                                cont++;
                                                System.out.println("["+cont+"]: "  + themes);
                                            }
                                            System.out.println("");
                                            System.out.println("Digite o numero de perguntas que deseja inserir:");
                                            nPerguntas = ler.nextInt();

                                            while (!(nPerguntas == 3 || nPerguntas == 4) ) {                                            
                                                System.out.println("O jogo deve possuir no minimo 3 perguntas e no maximo 4!");
                                                System.out.println("Digite novamente o numero de perguntas que deseja inserir: ");
                                                nPerguntas = ler.nextInt();
                                            }

                                            ler.nextLine();

                                            System.out.println("Digite qual o tema que deseja que a pergunta seja inserida:");
                                            temaP = ler.nextInt();

                                            System.out.println("");
                                            while (!(temaP == 4)) {
                                                System.out.println("Deve selecionar as opcoes disponiveis!");
                                                System.out.println("Digite navamente o tema que deseja que a pergunta seja inserida!");
                                                temaP = ler.nextInt();
                                            }
                                            //if (temaP == 4) {
                                            ler.nextLine();
                                                switch (temaP){
                                                    case 1:
                                                        if (nPerguntas == 3 || nPerguntas == 4) {
                                                            System.out.println("-----PREENCHIMENTO DAS PERGUNTAS PARA ESTE NIVEL-----");
                                                            cont = 0;
                                                            for (int i = 1; i <= nPerguntas; i++) {
                                                                cont++;
                                                                System.out.print("Pergunta [" +cont+ "]: ");
                                                                String  pergunta = ler.nextLine();
                                                                perguntas.add(pergunta);
                                                            }

                                                            ler.nextLine();

                                                            System.out.println("-----APRESENTACAO DAS PERGUNTAS-----");
                                                            cont = 0;
                                                            for (String question : perguntas) {
                                                                cont++;
                                                                System.out.println("["+ cont+"]: " + question);
                                                            }
                                                        }
                                                        break;
                                                    case 2:
                                                        if (nPerguntas == 3 || nPerguntas == 4) {
                                                            System.out.println("-----PREENCHIMENTO DAS PERGUNTAS PARA ESTE NIVEL-----");
                                                            cont = 0;
                                                            for (int i = 1; i <= nPerguntas; i++) {
                                                                cont++;
                                                                System.out.print("Pergunta [" +cont+ "]: ");
                                                                String  pergunta = ler.nextLine();
                                                                perguntas.add(pergunta);
                                                            }

                                                            ler.nextLine();

                                                            System.out.println("-----APRESENTACAO DAS PERGUNTAS-----");
                                                            cont = 0;
                                                            for (String question : perguntas) {
                                                                cont++;
                                                                System.out.println("["+ cont+"]: " + question);
                                                            }
                                                        }
                                                        break;
                                                    case 3:
                                                        if (nPerguntas == 3 || nPerguntas == 4) {
                                                            System.out.println("-----PREENCHIMENTO DAS PERGUNTAS PARA ESTE NIVEL-----");
                                                            cont = 0;
                                                            for (int i = 1; i <= nPerguntas; i++) {
                                                                cont++;
                                                                System.out.print("Pergunta [" +cont+ "]: ");
                                                                String  pergunta = ler.nextLine();
                                                                perguntas.add(pergunta);
                                                            }

                                                            ler.nextLine();

                                                            System.out.println("-----APRESENTACAO DAS PERGUNTAS-----");
                                                            cont = 0;
                                                            for (String question : perguntas) {
                                                                cont++;
                                                                System.out.println("["+ cont+"]: " + question);
                                                            }
                                                        }
                                                        break;
                                                    case 4:
                                                        if (nPerguntas == 3 || nPerguntas == 4) {
                                                            System.out.println("-----PREENCHIMENTO DAS PERGUNTAS PARA ESTE NIVEL-----");
                                                            cont = 0;
                                                            for (int i = 1; i <= nPerguntas; i++) {
                                                                cont++;
                                                                System.out.print("Pergunta [" +cont+ "]: ");
                                                                String  pergunta = ler.nextLine();
                                                                perguntas.add(pergunta);
                                                            }

                                                            ler.nextLine();

                                                            System.out.println("-----APRESENTACAO DAS PERGUNTAS-----");
                                                            cont = 0;
                                                            for (String question : perguntas) {
                                                                cont++;
                                                                System.out.println("["+ cont+"]: " + question);
                                                            }
                                                        }
                                                        break;*/
                                        case 3:
                                            /*System.out.println("Quantas temas deseja inserir? ");
                                            nTemas = ler.nextInt();
                                            System.out.println("Quais os temas que deseja para este nivel? ");

                                            ler.nextLine();

                                            while (!(nTemas == 4)) {                                        
                                                System.out.println("So pode ter ate 4 temas!");
                                                System.out.println("Digite novamente! ");
                                                nTemas = ler.nextInt();
                                                break;
                                            }

                                            ler.nextLine();

                                            if ((nTemas == 4)){
                                                for (int i = 1; i <= 4; i++) {
                                                    System.out.print("Tema [" + i + "]: ");
                                                    String tema = ler.nextLine();
                                                    temas.add(tema);
                                                }
                                            }

                                            ler.nextLine();

                                            cont = 0;
                                            System.out.println("-----TEMAS-----");
                                            for (String themes : temas) {
                                                cont++;
                                                System.out.println("["+cont+"]: "  + themes);
                                            }
                                            System.out.println("");
                                            System.out.println("Digite o numero de perguntas que deseja inserir:");
                                            nPerguntas = ler.nextInt();

                                            while (!(nPerguntas == 3 || nPerguntas == 4) ) {                                            
                                                System.out.println("O jogo deve possuir no minimo 3 perguntas! e no maximo 4!");
                                                System.out.println("Digite novamente o numero de perguntas que deseja inserir: ");
                                                nPerguntas = ler.nextInt();
                                            }

                                            ler.nextLine();

                                            System.out.println("Digite qual o tema que deseja que a pergunta seja inserida:");
                                            temaP = ler.nextInt();

                                            System.out.println("");
                                            /*while (!(temaP == 4)) {
                                                System.out.println("Deve selecionar as opcoes disponiveis!");
                                                System.out.println("Digite navamente o tema que deseja que a pergunta seja inserida!");
                                                temaP = ler.nextInt();
                                            }
                                            //if (temaP == 4) {
                                            ler.nextLine();
                                                switch (temaP){
                                                    case 1:
                                                        if (nPerguntas == 3 || nPerguntas == 4) {
                                                            System.out.println("-----PREENCHIMENTO DAS PERGUNTAS PARA ESTE NIVEL-----");
                                                            cont = 0;
                                                            for (int i = 1; i <= nPerguntas; i++) {
                                                                cont++;
                                                                System.out.print("Pergunta [" +cont+ "]: ");
                                                                String  pergunta = ler.nextLine();
                                                                perguntas.add(pergunta);
                                                            }

                                                            ler.nextLine();

                                                            System.out.println("-----APRESENTACAO DAS PERGUNTAS-----");
                                                            cont = 0;
                                                            for (String question : perguntas) {
                                                                cont++;
                                                                System.out.println("["+ cont+"]: " + question);
                                                            }
                                                        }
                                                        break;
                                                    case 2:
                                                        if (nPerguntas == 3 || nPerguntas == 4) {
                                                            System.out.println("-----PREENCHIMENTO DAS PERGUNTAS PARA ESTE NIVEL-----");
                                                            cont = 0;
                                                            for (int i = 1; i <= nPerguntas; i++) {
                                                                cont++;
                                                                System.out.print("Pergunta [" +cont+ "]: ");
                                                                String  pergunta = ler.nextLine();
                                                                perguntas.add(pergunta);
                                                            }

                                                            ler.nextLine();

                                                            System.out.println("-----APRESENTACAO DAS PERGUNTAS-----");
                                                            cont = 0;
                                                            for (String question : perguntas) {
                                                                cont++;
                                                                System.out.println("["+ cont+"]: " + question);
                                                            }
                                                        }
                                                        break;
                                                    case 3:
                                                        if (nPerguntas == 3 || nPerguntas == 4) {
                                                            System.out.println("-----PREENCHIMENTO DAS PERGUNTAS PARA ESTE NIVEL-----");
                                                            cont = 0;
                                                            for (int i = 1; i <= nPerguntas; i++) {
                                                                cont++;
                                                                System.out.print("Pergunta [" +cont+ "]: ");
                                                                String  pergunta = ler.nextLine();
                                                                perguntas.add(pergunta);
                                                            }

                                                            ler.nextLine();

                                                            System.out.println("-----APRESENTACAO DAS PERGUNTAS-----");
                                                            cont = 0;
                                                            for (String question : perguntas) {
                                                                cont++;
                                                                System.out.println("["+ cont+"]: " + question);
                                                            }
                                                        }
                                                        break;
                                                    case 4:
                                                        if (nPerguntas == 3 || nPerguntas == 4) {
                                                            System.out.println("-----PREENCHIMENTO DAS PERGUNTAS PARA ESTE NIVEL-----");
                                                            cont = 0;
                                                            for (int i = 1; i <= nPerguntas; i++) {
                                                                cont++;
                                                                System.out.print("Pergunta [" +cont+ "]: ");
                                                                String  pergunta = ler.nextLine();
                                                                perguntas.add(pergunta);
                                                            }

                                                            ler.nextLine();

                                                            System.out.println("-----APRESENTACAO DAS PERGUNTAS-----");
                                                            cont = 0;
                                                            for (String question : perguntas) {
                                                                cont++;
                                                                System.out.println("["+ cont+"]: " + question);
                                                            }
                                                        }
                                                        break;
                                                }
                                            break;*/
                                        case 4:
                                            /*System.out.println("Quantas temas deseja inserir? ");
                                            nTemas = ler.nextInt();
                                            System.out.println("Quais os temas que deseja para este nivel? ");

                                            ler.nextLine();

                                            while (!(nTemas == 4)) {                                        
                                                System.out.println("So pode ter ate 4 temas!");
                                                System.out.println("Digite novamente! ");
                                                nTemas = ler.nextInt();
                                                break;
                                            }

                                            ler.nextLine();

                                            if ((nTemas == 4)){
                                                for (int i = 1; i <= 4; i++) {
                                                    System.out.print("Tema [" + i + "]: ");
                                                    String tema = ler.nextLine();
                                                    temas.add(tema);
                                                }
                                            }

                                            ler.nextLine();

                                            cont = 0;
                                            System.out.println("-----TEMAS-----");
                                            for (String themes : temas) {
                                                cont++;
                                                System.out.println("["+cont+"]: "  + themes);
                                            }
                                            System.out.println("");
                                            System.out.println("Digite o numero de perguntas que deseja inserir:");
                                            nPerguntas = ler.nextInt();

                                            while (!(nPerguntas == 3 || nPerguntas == 4) ) {                                            
                                                System.out.println("O jogo deve possuir no minimo 3 perguntas e no maximo 4!");
                                                System.out.println("Digite novamente o numero de perguntas que deseja inserir: ");
                                                nPerguntas = ler.nextInt();
                                            }

                                            ler.nextLine();

                                            System.out.println("Digite qual o tema que deseja que a pergunta seja inserida:");
                                            temaP = ler.nextInt();

                                            System.out.println("");
                                            /*while (!(temaP == 4)) {
                                                System.out.println("Deve selecionar as opcoes disponiveis!");
                                                System.out.println("Digite navamente o tema que deseja que a pergunta seja inserida!");
                                                temaP = ler.nextInt();
                                            }
                                            if (temaP == 4) {
                                                ler.nextLine();
                                                switch (temaP){
                                                    case 1:
                                                        if (nPerguntas == 3 || nPerguntas == 4) {
                                                            System.out.println("-----PREENCHIMENTO DAS PERGUNTAS PARA ESTE NIVEL-----");
                                                            cont = 0;
                                                            for (int i = 1; i <= nPerguntas; i++) {
                                                                cont++;
                                                                System.out.print("Pergunta [" +cont+ "]: ");
                                                                String  pergunta = ler.nextLine();
                                                                perguntas.add(pergunta);
                                                            }

                                                            ler.nextLine();

                                                            System.out.println("-----APRESENTACAO DAS PERGUNTAS-----");
                                                            cont = 0;
                                                            for (String question : perguntas) {
                                                                cont++;
                                                                System.out.println("["+ cont+"]: " + question);
                                                            }
                                                        }
                                                        break;
                                                    case 2:
                                                        if (nPerguntas == 3 || nPerguntas == 4) {
                                                            System.out.println("-----PREENCHIMENTO DAS PERGUNTAS PARA ESTE NIVEL-----");
                                                            cont = 0;
                                                            for (int i = 1; i <= nPerguntas; i++) {
                                                                cont++;
                                                                System.out.print("Pergunta [" +cont+ "]: ");
                                                                String  pergunta = ler.nextLine();
                                                                perguntas.add(pergunta);
                                                            }

                                                            ler.nextLine();

                                                            System.out.println("-----APRESENTACAO DAS PERGUNTAS-----");
                                                            cont = 0;
                                                            for (String question : perguntas) {
                                                                cont++;
                                                                System.out.println("["+ cont+"]: " + question);
                                                            }
                                                        }
                                                        break;
                                                    case 3:
                                                        if (nPerguntas == 3 || nPerguntas == 4) {
                                                            System.out.println("-----PREENCHIMENTO DAS PERGUNTAS PARA ESTE NIVEL-----");
                                                            cont = 0;
                                                            for (int i = 1; i <= nPerguntas; i++) {
                                                                cont++;
                                                                System.out.print("Pergunta [" +cont+ "]: ");
                                                                String  pergunta = ler.nextLine();
                                                                perguntas.add(pergunta);
                                                            }

                                                            ler.nextLine();

                                                            System.out.println("-----APRESENTACAO DAS PERGUNTAS-----");
                                                            cont = 0;
                                                            for (String question : perguntas) {
                                                                cont++;
                                                                System.out.println("["+ cont+"]: " + question);
                                                            }
                                                        }
                                                        break;
                                                    case 4:
                                                        if (nPerguntas == 3 || nPerguntas == 4) {
                                                            System.out.println("-----PREENCHIMENTO DAS PERGUNTAS PARA ESTE NIVEL-----");
                                                            cont = 0;
                                                            for (int i = 1; i <= nPerguntas; i++) {
                                                                cont++;
                                                                System.out.print("Pergunta [" +cont+ "]: ");
                                                                String  pergunta = ler.nextLine();
                                                                perguntas.add(pergunta);
                                                            }

                                                            ler.nextLine();

                                                            System.out.println("-----APRESENTACAO DAS PERGUNTAS-----");
                                                            cont = 0;
                                                            for (String question : perguntas) {
                                                                cont++;
                                                                System.out.println("["+ cont+"]: " + question);
                                                            }
                                                        }
                                                        break;
                                                    }
                                                }
                                            break;*/
                                        //}
                                    }
                                }
                                break;
                        case 3:
                            break;
                    }
                }
                cont++;
                System.out.println("");
            }while(cont != 3);
    }
}
